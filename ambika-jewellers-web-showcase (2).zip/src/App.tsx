/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { About } from './pages/About';
import { Categories } from './pages/Categories';
import { Products } from './pages/Products';
import { Contact } from './pages/Contact';
import { AddItem } from './pages/AddItem';
import { Wishlist } from './pages/Wishlist';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      {
        index: true,
        element: <Home />,
      },
      {
        path: 'about',
        element: <About />,
      },
      {
        path: 'categories',
        element: <Categories />,
      },
      {
        path: 'categories/:categoryId',
        element: <Products />,
      },
      {
        path: 'contact',
        element: <Contact />,
      },
      {
        path: 'add-item',
        element: <AddItem />,
      },
      {
        path: 'wishlist',
        element: <Wishlist />,
      },
    ],
  },
]);

import { WishlistProvider } from './context/WishlistContext';
import { AuthProvider } from './context/AuthContext';

export default function App() {
  return (
    <AuthProvider>
      <WishlistProvider>
        <RouterProvider router={router} />
      </WishlistProvider>
    </AuthProvider>
  );
}


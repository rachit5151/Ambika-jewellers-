import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Search, Heart } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import { flatProducts } from '../data/products';
import { useWishlist } from '../context/WishlistContext';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const location = useLocation();
  const { wishlist } = useWishlist();

  const links = [
    { name: 'Home', path: '/' },
    { name: 'About Us', path: '/about' },
    { name: 'Collections', path: '/categories' },
    { name: 'Contact', path: '/contact' },
    { name: 'Add Item', path: '/add-item' },
  ];

  const isActive = (path: string) => {
    if (path === '/' && location.pathname !== '/') return false;
    return location.pathname.startsWith(path);
  };

  const searchResults = searchQuery
    ? flatProducts.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.description.toLowerCase().includes(searchQuery.toLowerCase()))
    : [];

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSearch(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Close mobile menu and search on route change
  useEffect(() => {
    setIsOpen(false);
    setShowSearch(false);
    setSearchQuery('');
  }, [location.pathname]);

  return (
    <header className="bg-charcoal-900 text-white sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex-shrink-0 flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden text-gray-300 hover:text-white focus:outline-none mr-4"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
            <Link to="/" className="font-serif text-xl md:text-2xl tracking-wider text-gold-500 font-medium">
              AMBIKA JEWELLERS
            </Link>
          </div>
          
          <nav className="hidden md:flex space-x-8 lg:space-x-12">
            {links.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`text-sm font-medium tracking-wide uppercase transition-colors duration-200 flex items-center ${
                  isActive(link.path) ? 'text-gold-500' : 'text-gray-300 hover:text-gold-400'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Search Bar - Visible on all screens */}
          <div className="flex-1 max-w-lg mx-4 md:mx-12" ref={searchRef}>
            <div className="relative group">
              <input
                type="text"
                placeholder="Search jewellery..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setShowSearch(true);
                }}
                onFocus={() => setShowSearch(true)}
                className="w-full bg-charcoal-800 border border-charcoal-700 text-sm text-gray-200 placeholder-gray-500 rounded-full pl-10 pr-4 py-2 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-light group-hover:border-gray-600"
              />
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
            </div>

            {/* Desktop & Mobile Search Results Dropdown */}
            {showSearch && searchQuery && (
              <div className="absolute top-14 left-4 right-4 md:left-auto md:right-auto md:w-[450px] bg-white rounded-sm shadow-2xl border border-gray-100 overflow-hidden text-charcoal-900 z-50 max-h-96 overflow-y-auto">
                {searchResults.length > 0 ? (
                  <div className="py-2">
                    {searchResults.map(product => (
                      <Link 
                        key={product.id} 
                        to={`/categories/${product.category}`}
                        className="flex items-center px-4 py-3 hover:bg-ivory border-b border-gray-50 last:border-0 transition"
                        onClick={() => setShowSearch(false)}
                      >
                        <img src={product.image} alt={product.name} className="w-12 h-12 object-cover rounded-sm border border-gray-100 flex-shrink-0" />
                        <div className="ml-3 overflow-hidden">
                          <p className="text-sm font-serif truncate text-charcoal-800">{product.name}</p>
                          <p className="text-xs text-gray-500 mt-1">{product.price}</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                ) : (
                  <div className="px-4 py-6 text-center text-sm text-gray-500 font-light">
                    No matching jewellery found.
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="flex flex-none justify-end items-center md:mr-0">
            <Link to="/wishlist" className="relative text-gray-300 hover:text-gold-500 transition">
              <Heart className="h-5 w-5" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1.5 -right-2 bg-gold-500 text-charcoal-900 text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </Link>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-charcoal-800 border-t border-charcoal-700">
          <div className="px-2 pt-4 pb-3 space-y-1 sm:px-3">
            {links.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`block px-3 py-2 rounded-md text-base font-medium ${
                  isActive(link.path)
                    ? 'text-gold-500 bg-charcoal-900'
                    : 'text-gray-300 hover:text-white hover:bg-charcoal-700'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}

import { Facebook, Instagram, Twitter, MapPin, Phone, Mail } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Footer() {
  return (
    <footer className="bg-charcoal-900 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          
          <div>
            <h2 className="font-serif text-2xl text-gold-500 mb-6 font-medium tracking-wider">
              AMBIKA JEWELLERS
            </h2>
            <p className="text-gray-400 text-sm leading-relaxed mb-6 font-light">
              Elegance Within Your Reach. We provide premium 1-gram gold and artificial 
              jewellery for every occasion, bringing royal aesthetics to your everyday life.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="h-10 w-10 rounded-full bg-charcoal-800 flex items-center justify-center text-gray-400 hover:text-gold-500 hover:bg-charcoal-700 transition">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="h-10 w-10 rounded-full bg-charcoal-800 flex items-center justify-center text-gray-400 hover:text-gold-500 hover:bg-charcoal-700 transition">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="h-10 w-10 rounded-full bg-charcoal-800 flex items-center justify-center text-gray-400 hover:text-gold-500 hover:bg-charcoal-700 transition">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-serif text-lg mb-6 tracking-wide text-gray-200">Quick Links</h3>
            <ul className="space-y-4 text-sm text-gray-400 font-light">
              <li><Link to="/" className="hover:text-gold-500 transition">Home</Link></li>
              <li><Link to="/about" className="hover:text-gold-500 transition">About Us</Link></li>
              <li><Link to="/categories" className="hover:text-gold-500 transition">Our Collections</Link></li>
              <li><Link to="/contact" className="hover:text-gold-500 transition">Contact Us</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-serif text-lg mb-6 tracking-wide text-gray-200">Contact Info</h3>
            <ul className="space-y-4 text-sm text-gray-400 font-light">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 text-gold-500 mr-3 flex-shrink-0 mt-0.5" />
                <span>Patel Colony, Indore<br />Madhya Pradesh, 452001</span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 text-gold-500 mr-3 flex-shrink-0" />
                <span>+91 98765 43210</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 text-gold-500 mr-3 flex-shrink-0" />
                <span>info@ambikajewellers.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-charcoal-800 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-500 font-light text-center md:text-left">
            &copy; {new Date().getFullYear()} Ambika Jewellers. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}

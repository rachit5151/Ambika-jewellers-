import royalTrapezoidalImg from '../assets/images/royal_gold_necklace_1781518053944.jpg';
import heartRaniHaarImg from '../assets/images/ambika_jewellers_rani_haar_1781518294982.jpg';

export interface Product {
  id: number;
  name: string;
  price: string;
  image: string;
  images?: string[];
  description: string;
  category: string;
  inStock?: boolean;
}

const LOCAL_STORAGE_KEY = 'ambika_jewellers_v1_products';

const getInitialData = (): Record<string, Omit<Product, 'category'>[]> => {
  try {
    const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (stored) return JSON.parse(stored);
  } catch (e) {
    console.error('Failed to load from local storage', e);
  }
  return {
    'rani-haar': [
      { id: 10, name: 'Royal Trapezoidal Gold Pendant', price: '₹ 5,500', image: royalTrapezoidalImg, description: '1-Gram gold necklace with exquisite red enamel detailing on a majestic trapezoidal pendant.' },
      { id: 11, name: 'Premium Heart Motif Rani Haar', price: '₹ 3,300', image: heartRaniHaarImg, description: '5 year warranty' },
      { id: 1, name: 'Kundan Royal Rani Haar', price: '₹ 4,500', image: 'https://images.unsplash.com/photo-1599643477877-521ee2e27b6e?auto=format&fit=crop&q=80&w=600', description: 'Intricate kundan work with pearl drops.' },
      { id: 2, name: '1-Gram Gold Antique Long Necklace', price: '₹ 3,200', image: 'https://images.unsplash.com/photo-1599643478514-4a4208000b0d?auto=format&fit=crop&q=80&w=600', description: 'Classic temple jewellery design with a matte gold finish.' },
      { id: 3, name: 'Polki Statement Haar', price: '₹ 5,100', image: 'https://images.unsplash.com/photo-1611085583191-a3b181a88401?auto=format&fit=crop&q=80&w=600', description: 'Heavy polki setting for bridal wear.' },
    ],
    'mangalsutra': [
      { id: 12, name: 'Traditional Maharashtrian Vati', price: '₹ 2,500', image: 'https://images.unsplash.com/photo-1599643477877-521ee2e27b6e?auto=format&fit=crop&q=80&w=600', description: 'Authentic twin-vati design honoring rich heritage with black beads.' },
      { id: 13, name: 'Modern Minimalist', price: '₹ 1,800', image: 'https://images.unsplash.com/photo-1599643478514-4a4208000b0d?auto=format&fit=crop&q=80&w=600', description: 'Sleek single-diamond design exclusively for working women.' },
      { id: 14, name: 'Diamond-Studded Elegance', price: '₹ 3,400', image: 'https://images.unsplash.com/photo-1611085583191-a3b181a88401?auto=format&fit=crop&q=80&w=600', description: 'Luxurious American Diamond settings merged with black beads.' },
      { id: 15, name: '1-Gram Gold Daily Wear', price: '₹ 1,200', image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&q=80&w=600', description: 'Durable micro-plated chains that withstand daily chores.' },
    ],
    'bangles': [
      { id: 16, name: 'Heavy Traditional Bridal Kangan', price: '₹ 3,500', image: 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?auto=format&fit=crop&q=80&w=600', description: 'Detailed meenakari and stone settings, perfect for cultural grandeur.' },
      { id: 17, name: 'Sleek Modern Kada', price: '₹ 1,500', image: 'https://images.unsplash.com/photo-1599643477877-521ee2e27b6e?auto=format&fit=crop&q=80&w=600', description: 'Subtle sophistication for everyday style.' },
    ],
    'chains': [
      { id: 18, name: 'Daily Wear Gold Polish Chain', price: '₹ 800', image: 'https://images.unsplash.com/photo-1599643478514-4a4208000b0d?auto=format&fit=crop&q=80&w=600', description: 'Simple and elegant micro-plated chain for everyday use.' },
      { id: 19, name: 'Thick Rope Chain', price: '₹ 1,200', image: 'https://images.unsplash.com/photo-1611085583191-a3b181a88401?auto=format&fit=crop&q=80&w=600', description: 'Sturdy 1-gram gold rope chain perfect for heavy pendants.' },
      { id: 20, name: 'Designer Matar Mala Chain', price: '₹ 1,500', image: 'https://images.unsplash.com/photo-1599643477877-521ee2e27b6e?auto=format&fit=crop&q=80&w=600', description: 'Traditional beaded gold polish chain with high shine.' },
    ],
    'bracelets': [
      { id: 4, name: 'Gold-Plated Kada', price: '₹ 1,200', image: 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?auto=format&fit=crop&q=80&w=600', description: 'Traditional thick kada with screw closure.' },
      { id: 5, name: 'American Diamond Sleek Bracelet', price: '₹ 850', image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&q=80&w=600', description: 'Minimalist AD bracelet for western or party wear.' },
    ],
    'rings': [
      { id: 6, name: 'Traditional Meenakari Ring', price: '₹ 450', image: 'https://images.unsplash.com/photo-1605100804763-247f66126e28?auto=format&fit=crop&q=80&w=600', description: 'Adjustable ring with vibrant meenakari enamel.' },
      { id: 7, name: 'Adjustable Solitaire Ring', price: '₹ 600', image: 'https://images.unsplash.com/photo-1605100804763-247f66126e28?auto=format&fit=crop&q=80&w=600', description: 'Large single American Diamond set in silver tone.' },
    ],
    'earrings': [
      { id: 8, name: 'Classic Gold Jhumka', price: '₹ 950', image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&q=80&w=600', description: 'Everyday traditional jhumkas with micro gold plating.' },
      { id: 9, name: 'Modern Pearl Drop Earrings', price: '₹ 650', image: 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?auto=format&fit=crop&q=80&w=600', description: 'Elegant faux pearl drops for a sophisticated look.' },
    ]
  };
};

export const allProducts: Record<string, Omit<Product, 'category'>[]> = getInitialData();

export const flatProducts: Product[] = Object.entries(allProducts).flatMap(([category, items]) =>
  items.map(item => ({ ...item, category }))
);

const saveProducts = () => {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(allProducts));
  } catch (e) {
    console.error('Failed to save to local storage', e);
  }
};

export function addProduct(productData: Omit<Product, 'id'>) {
  const newId = Math.max(0, ...flatProducts.map(p => p.id)) + 1;
  const newProduct = { ...productData, id: newId };
  
  const { category, ...productWithoutCategory } = newProduct;
  
  if (!allProducts[category]) {
    allProducts[category] = [];
  }
  
  allProducts[category].push(productWithoutCategory);
  flatProducts.push(newProduct);
  
  saveProducts();
  return newProduct;
}

export function deleteProduct(id: number) {
  const index = flatProducts.findIndex(p => p.id === id);
  if (index !== -1) {
    const category = flatProducts[index].category;
    flatProducts.splice(index, 1);
    allProducts[category] = allProducts[category].filter(p => p.id !== id);
    saveProducts();
    return true;
  }
  return false;
}

export function updateProductStock(id: number, inStock: boolean) {
  const product = flatProducts.find(p => p.id === id);
  if (product) {
    product.inStock = inStock;
    const categoryList = allProducts[product.category];
    if (categoryList) {
      const catProduct = categoryList.find(p => p.id === id);
      if (catProduct) catProduct.inStock = inStock;
    }
    saveProducts();
    return true;
  }
  return false;
}

export const categoryNames: Record<string, string> = {
  'rani-haar': 'Rani Haar',
  'mangalsutra': 'Mangalsutra',
  'bangles': 'Bangles & Kangans',
  'chains': 'Gold Polish Chains',
  'bracelets': 'Bracelets',
  'rings': 'Rings',
  'earrings': 'Earrings',
};

import { useState, useRef, useEffect } from 'react';
import { UploadCloud, Image as ImageIcon, X, CheckCircle2, Lock, LogOut, Trash2 } from 'lucide-react';
import { categoryNames, addProduct, flatProducts, deleteProduct, updateProductStock, Product } from '../data/products';
import { useAuth } from '../context/AuthContext';

export function AddItem() {
  const { isAdmin, login, logout } = useAuth();
  const [password, setPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const [dragActive, setDragActive] = useState(false);
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  
  const [refresh, setRefresh] = useState(0);
  const [inventory, setInventory] = useState<Product[]>([]);
  const [selectedItems, setSelectedItems] = useState<number[]>([]);

  useEffect(() => {
    setInventory([...flatProducts]);
  }, [refresh]);

  const toggleItemSelection = (id: number) => {
    setSelectedItems(prev => prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]);
  };

  const toggleSelectAll = () => {
    if (selectedItems.length === inventory.length && inventory.length > 0) {
      setSelectedItems([]);
    } else {
      setSelectedItems(inventory.map(item => item.id));
    }
  };

  const handleBulkDelete = () => {
    if (selectedItems.length === 0) return;
    if (window.confirm(`Are you sure you want to delete ${selectedItems.length} selected item(s)?`)) {
      selectedItems.forEach(id => deleteProduct(id));
      setRefresh(prev => prev + 1);
      setSelectedItems([]);
    }
  };

  const handleToggleStock = (id: number, currentStock: boolean | undefined) => {
    // Treat undefined as true initially
    updateProductStock(id, currentStock === undefined ? false : !currentStock);
    setRefresh(prev => prev + 1);
  };

  const handleDeleteItem = (id: number) => {
    if (window.confirm('Are you sure you want to delete this specific item from the inventory?')) {
      if (deleteProduct(id)) {
        setRefresh(prev => prev + 1);
      }
    }
  };
  
  const [activeTab, setActiveTab] = useState<'add' | 'items'>('add');
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    quantity: '',
    category: 'rani-haar',
    description: ''
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  const inputRef = useRef<HTMLInputElement>(null);

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(password)) {
      setPasswordError('');
      setPassword('');
    } else {
      setPasswordError('Invalid password. Please try again.');
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files.length > 0) {
      handleFiles(Array.from(e.target.files));
    }
  };

  const handleFiles = (files: File[]) => {
    const validFiles = files.filter(file => file.type.startsWith('image/'));
    if (validFiles.length !== files.length) {
      alert('Please upload only image files');
    }

    if (validFiles.length === 0) return;

    setImageFiles(prev => [...prev, ...validFiles]);

    validFiles.forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 600;
          const MAX_HEIGHT = 600;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.6);
            setImagePreviews(prev => [...prev, dataUrl]);
          }
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImageFiles(prev => prev.filter((_, i) => i !== index));
    setImagePreviews(prev => prev.filter((_, i) => i !== index));
    if (inputRef.current) {
      inputRef.current.value = '';
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Process form and add to collection
    setTimeout(() => {
      // Format the price
      const formattedPrice = `₹ ${Number(formData.price).toLocaleString('en-IN')}`;
      
      // Use the preview images as the product images
      addProduct({
        name: formData.name,
        price: formattedPrice,
        image: imagePreviews.length > 0 ? imagePreviews[0] : '',
        images: imagePreviews,
        category: formData.category,
        description: formData.description || 'No description provided.'
      });
      
      setRefresh(prev => prev + 1);
      setIsSubmitting(false);
      setIsSuccess(true);
      
      // Reset form after short delay
      setTimeout(() => {
        setIsSuccess(false);
        setFormData({
          name: '',
          price: '',
          quantity: '',
          category: 'rani-haar',
          description: ''
        });
        setImageFiles([]);
        setImagePreviews([]);
        if (inputRef.current) inputRef.current.value = '';
      }, 3000);
    }, 1000);
  };

  if (!isAdmin) {
    return (
      <div className="bg-ivory min-h-screen pt-24 pb-24 flex items-center justify-center">
        <div className="max-w-md w-full mx-auto px-4">
          <div className="bg-white rounded-sm shadow-xl p-8 border-t-4 border-gold-500">
            <div className="text-center mb-8">
              <div className="h-16 w-16 bg-charcoal-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lock className="h-8 w-8 text-charcoal-900" />
              </div>
              <h1 className="font-serif text-2xl text-charcoal-900 mb-2">Admin Access</h1>
              <p className="text-gray-500 font-light text-sm mb-2">Please enter the password to access the inventory.</p>
            </div>
            
            <form onSubmit={handlePasswordSubmit} className="space-y-6">
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-charcoal-800 mb-2">Password</label>
                <input 
                  type="password" 
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full border border-gray-300 rounded-sm px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition" 
                  placeholder="Enter password"
                  autoFocus
                />
                {passwordError && (
                  <p className="text-rose-500 text-sm mt-2">{passwordError}</p>
                )}
              </div>
              <button 
                type="submit" 
                className="w-full bg-charcoal-900 text-gold-500 hover:bg-gold-500 hover:text-charcoal-900 px-8 py-3 rounded-sm font-medium transition duration-300"
              >
                Access Dashboard
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-ivory min-h-screen pt-12 pb-24">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-8">
          <div className="text-center md:text-left mb-6 md:mb-0">
            <h1 className="font-serif text-3xl md:text-4xl text-charcoal-900 mb-4">Admin Dashboard</h1>
            <div className="h-0.5 w-16 bg-gold-500 mx-auto md:mx-0 mb-4"></div>
            <p className="text-gray-500 font-light">
              Manage your inventory and add new products to the catalog.
            </p>
          </div>
          
          <button 
            onClick={logout}
            className="flex items-center text-rose-500 hover:text-rose-700 transition font-medium text-sm self-center md:self-end"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </button>
        </div>

        <div className="flex mb-8 border-b border-gray-200">
          <button
            className={`py-3 px-6 text-sm font-medium tracking-wide transition-colors ${
              activeTab === 'add'
                ? 'text-gold-600 border-b-2 border-gold-500'
                : 'text-gray-500 hover:text-charcoal-900 hover:border-gray-300 border-b-2 border-transparent'
            }`}
            onClick={() => setActiveTab('add')}
          >
            Add New Item
          </button>
          <button
            className={`py-3 px-6 text-sm font-medium tracking-wide transition-colors ${
              activeTab === 'items'
                ? 'text-gold-600 border-b-2 border-gold-500'
                : 'text-gray-500 hover:text-charcoal-900 hover:border-gray-300 border-b-2 border-transparent'
            }`}
            onClick={() => setActiveTab('items')}
          >
            Inventory Items
          </button>
        </div>

        {activeTab === 'add' && (
          <div className="bg-white rounded-sm shadow-xl p-6 md:p-10 border-t-4 border-gold-500">
            {isSuccess ? (
            <div className="flex flex-col items-center justify-center py-16 text-center animate-in fade-in zoom-in duration-500">
              <div className="h-20 w-20 bg-green-50 rounded-full flex items-center justify-center mb-6">
                <CheckCircle2 className="h-10 w-10 text-green-500" />
              </div>
              <h2 className="font-serif text-2xl text-charcoal-900 mb-2">Item Added Successfully!</h2>
              <p className="text-gray-500 font-light">
                The new jewellery piece has been logged and added to the inventory.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-8 animate-in fade-in duration-300">
              
              {/* Image Upload Area */}
              <div>
                <label className="block text-sm font-medium text-charcoal-800 mb-3">Product Images</label>
                
                {imagePreviews.length > 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-4">
                    {imagePreviews.map((preview, idx) => (
                      <div key={idx} className="relative rounded-sm overflow-hidden border border-gray-200 bg-gray-50 group aspect-square flex items-center justify-center">
                        <img 
                          src={preview} 
                          alt={`Preview ${idx + 1}`} 
                          className="max-h-full max-w-full object-cover w-full h-full"
                        />
                        <div className="absolute inset-0 bg-charcoal-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <button 
                            type="button"
                            onClick={() => removeImage(idx)}
                            className="bg-white text-rose-600 rounded-full p-2 text-sm font-medium hover:bg-gray-100 transition shadow-sm"
                          >
                            <X className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <div 
                  className={`relative border-2 border-dashed rounded-sm p-10 text-center transition-colors cursor-pointer ${
                    dragActive ? 'border-gold-500 bg-gold-50/50' : 'border-gray-300 hover:bg-gray-50'
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                  onClick={() => inputRef.current?.click()}
                >
                  <input
                    ref={inputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleChange}
                    className="hidden"
                  />
                  <UploadCloud className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <p className="text-charcoal-800 font-medium mb-1">Click to upload or drag and drop</p>
                  <p className="text-xs text-gray-500 font-light">SVG, PNG, JPG or GIF (max. 5MB per file)</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <label htmlFor="name" className="block text-sm font-medium text-charcoal-800 mb-2">Item Name</label>
                  <input 
                    type="text" 
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    placeholder="e.g. Royal Trapezoidal Gold Pendant"
                    className="w-full border border-gray-300 rounded-sm px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition" 
                  />
                </div>

                <div>
                  <label htmlFor="price" className="block text-sm font-medium text-charcoal-800 mb-2">Price (₹)</label>
                  <input 
                    type="number" 
                    id="price"
                    name="price"
                    value={formData.price}
                    onChange={handleInputChange}
                    required
                    min="0"
                    placeholder="0.00"
                    className="w-full border border-gray-300 rounded-sm px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition" 
                  />
                </div>

                <div>
                  <label htmlFor="quantity" className="block text-sm font-medium text-charcoal-800 mb-2">Quantity in Stock</label>
                  <input 
                    type="number" 
                    id="quantity"
                    name="quantity"
                    value={formData.quantity}
                    onChange={handleInputChange}
                    required
                    min="1"
                    placeholder="1"
                    className="w-full border border-gray-300 rounded-sm px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition" 
                  />
                </div>

                <div className="md:col-span-2">
                  <label htmlFor="category" className="block text-sm font-medium text-charcoal-800 mb-2">Category</label>
                  <select 
                    id="category"
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    className="w-full border border-gray-300 rounded-sm px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition cursor-pointer appearance-none bg-white" 
                  >
                    {Object.entries(categoryNames).map(([key, value]) => (
                      <option key={key} value={key}>{value}</option>
                    ))}
                  </select>
                </div>
                
                <div className="md:col-span-2">
                  <label htmlFor="description" className="block text-sm font-medium text-charcoal-800 mb-2">Description (Optional)</label>
                  <textarea 
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows={3}
                    placeholder="Brief description about the item..."
                    className="w-full border border-gray-300 rounded-sm px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition resize-none" 
                  ></textarea>
                </div>
              </div>

              <div className="pt-4 border-t border-gray-100 flex justify-end">
                <button 
                  type="submit" 
                  disabled={isSubmitting || imageFiles.length === 0}
                  className={`px-8 py-3 rounded-sm font-medium tracking-wide transition duration-300 flex items-center ${
                    isSubmitting || imageFiles.length === 0 
                      ? 'bg-gray-200 text-gray-500 cursor-not-allowed' 
                      : 'bg-charcoal-900 text-gold-500 hover:bg-gold-500 hover:text-charcoal-900 shadow-md'
                  }`}
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-gray-500 border-t-transparent mr-2"></div>
                      Processing...
                    </>
                  ) : (
                    'Add Item to Inventory'
                  )}
                </button>
              </div>
            </form>
            )}
          </div>
        )}
        
        {/* Inventory Management Section */}
        {activeTab === 'items' && (
          <div className="bg-white rounded-sm shadow-xl p-6 md:p-10 border-t-4 border-gold-500">
            <div className="flex justify-between items-center mb-8">
              <h2 className="font-serif text-2xl text-charcoal-900">Current Inventory Management</h2>
              <div className="flex items-center space-x-4">
                {selectedItems.length > 0 && (
                  <button
                    onClick={handleBulkDelete}
                    className="flex items-center px-4 py-1.5 bg-rose-50 text-rose-600 hover:bg-rose-100 text-sm font-medium rounded-md transition"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete Selected ({selectedItems.length})
                  </button>
                )}
                <div className="px-3 py-1 bg-gold-50 text-gold-700 text-xs font-bold rounded-full uppercase tracking-wider">
                  {inventory.length} Items Total
                </div>
              </div>
            </div>
            
            {inventory.length === 0 ? (
              <div className="text-center py-12 text-gray-500 font-light">
                No items currently in inventory.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-gray-200 text-xs uppercase tracking-wider text-gray-500">
                      <th className="pb-3 font-medium w-10">
                        <input
                          type="checkbox"
                          checked={selectedItems.length === inventory.length && inventory.length > 0}
                          onChange={toggleSelectAll}
                          className="rounded border-gray-300 text-gold-500 focus:ring-gold-500"
                        />
                      </th>
                      <th className="pb-3 font-medium">Item</th>
                      <th className="pb-3 font-medium">Category</th>
                      <th className="pb-3 font-medium">Price</th>
                      <th className="pb-3 font-medium">Status</th>
                      <th className="pb-3 font-medium text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {inventory.map((item) => (
                      <tr key={item.id} className={`hover:bg-gray-50 transition border-l-2 ${selectedItems.includes(item.id) ? 'bg-gold-50/30 border-gold-500' : 'border-transparent'}`}>
                        <td className="py-4 pl-3">
                          <input
                            type="checkbox"
                            checked={selectedItems.includes(item.id)}
                            onChange={() => toggleItemSelection(item.id)}
                            className="rounded border-gray-300 text-gold-500 focus:ring-gold-500"
                          />
                        </td>
                        <td className="py-4 flex items-center">
                          <img src={item.image || 'https://via.placeholder.com/150'} alt={item.name} className="w-10 h-10 object-cover rounded-sm border border-gray-200 mr-3" />
                          <span className="font-medium text-charcoal-900 text-sm line-clamp-1">{item.name}</span>
                        </td>
                        <td className="py-4 text-sm text-gray-600 font-light">
                          {categoryNames[item.category] || item.category}
                        </td>
                        <td className="py-4 text-sm text-charcoal-800 font-medium whitespace-nowrap">
                          {item.price}
                        </td>
                        <td className="py-4 text-sm">
                          <button
                            onClick={() => handleToggleStock(item.id, item.inStock)}
                            className={`px-2.5 py-1 text-xs font-medium rounded-full transition-colors ${
                              item.inStock !== false 
                                ? 'bg-green-100 text-green-700 hover:bg-green-200' 
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                            }`}
                          >
                            {item.inStock !== false ? 'In Stock' : 'Out of Stock'}
                          </button>
                        </td>
                        <td className="py-4 text-right">
                          <button 
                            onClick={() => handleDeleteItem(item.id)}
                            className="p-2 text-gray-400 hover:text-rose-500 hover:bg-rose-50 rounded-full transition"
                            title="Delete Item"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
}

import { Link } from 'react-router-dom';

const categories = [
  {
    id: 'rani-haar',
    name: 'Rani Haar',
    description: 'Royal Long Necklaces for majestic grace',
    image: 'https://images.unsplash.com/photo-1599643477877-521ee2e27b6e?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'mangalsutra',
    name: 'Mangalsutra',
    description: 'Sacred bonds crafted in premium designs',
    image: 'https://images.unsplash.com/photo-1611085583191-a3b181a88401?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'bangles',
    name: 'Bangles & Kangans',
    description: 'Traditional and modern wrist wear',
    image: 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'chains',
    name: 'Gold Polish Chains',
    description: 'High-quality micro-plated daily wear chains',
    image: 'https://images.unsplash.com/photo-1599643478514-4a4208000b0d?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'bracelets',
    name: 'Bracelets',
    description: 'Elegant wristwear from sleek designs to heavy kadas',
    image: 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'rings',
    name: 'Rings',
    description: 'Statement & casual rings with intricate detailing',
    image: 'https://images.unsplash.com/photo-1605100804763-247f66126e28?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'earrings',
    name: 'Earrings',
    description: 'Jhumkas, studs, and hangings for every occasion',
    image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&q=80&w=800',
  }
];

export function Categories() {
  return (
    <div className="bg-white min-h-screen pt-12 pb-24">
      <div className="text-center mb-16 px-4">
        <h1 className="font-serif text-4xl md:text-5xl text-charcoal-900 mb-4">Our Collections</h1>
        <div className="h-0.5 w-24 bg-gold-500 mx-auto mb-6"></div>
        <p className="text-gray-500 font-light max-w-2xl mx-auto">
          Explore our wide range of meticulously crafted artificial jewellery. 
          Browse categories below to find your perfect adornment.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {categories.map((category) => (
            <div key={category.id} className="group relative overflow-hidden rounded-sm bg-gray-100 shadow-md">
              <div className="aspect-w-16 aspect-h-11 sm:aspect-h-10">
                <img 
                  src={category.image} 
                  alt={category.name} 
                  className="w-full h-[400px] object-cover object-center group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-900/90 via-charcoal-900/40 to-transparent flex flex-col justify-end p-8">
                <h2 className="font-serif text-3xl text-white mb-2">{category.name}</h2>
                <p className="text-gray-300 font-light mb-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300 transform translate-y-4 group-hover:translate-y-0">
                  {category.description}
                </p>
                <Link 
                  to={`/categories/${category.id}`} 
                  className="inline-block border border-gold-500 text-gold-500 px-6 py-2 uppercase tracking-wider text-sm font-medium hover:bg-gold-500 hover:text-charcoal-900 transition w-fit"
                >
                  View Collection
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

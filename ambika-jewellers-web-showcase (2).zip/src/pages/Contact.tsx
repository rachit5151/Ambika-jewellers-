import { MapPin, Phone, Mail, Clock } from 'lucide-react';

export function Contact() {
  return (
    <div className="bg-white min-h-screen pt-12 pb-24">
      {/* Header */}
      <div className="text-center mb-16 px-4">
        <h1 className="font-serif text-4xl md:text-5xl text-charcoal-900 mb-4">Contact Us</h1>
        <div className="h-0.5 w-24 bg-gold-500 mx-auto mb-6"></div>
        <p className="text-gray-500 font-light max-w-2xl mx-auto">
          We would love to hear from you. Visit our store or reach out for inquiries regarding our collections, custom orders, or any other assistance.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Contact Details & Form */}
          <div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-12">
              <div className="bg-ivory p-6 rounded-sm">
                <MapPin className="h-8 w-8 text-gold-500 mb-4" />
                <h3 className="font-serif text-xl text-charcoal-900 mb-2">Visit Store</h3>
                <p className="text-gray-600 font-light text-sm">
                  Shop No. 4, Main Market,<br />
                  Patel Colony,<br />
                  Indore, MP 452001
                </p>
              </div>
              
              <div className="bg-ivory p-6 rounded-sm">
                <Phone className="h-8 w-8 text-gold-500 mb-4" />
                <h3 className="font-serif text-xl text-charcoal-900 mb-2">Call Us</h3>
                <p className="text-gray-600 font-light text-sm mb-1">
                  +91 98765 43210
                </p>
                <p className="text-gray-600 font-light text-sm">
                  +91 91234 56789
                </p>
              </div>
              
              <div className="bg-ivory p-6 rounded-sm">
                <Mail className="h-8 w-8 text-gold-500 mb-4" />
                <h3 className="font-serif text-xl text-charcoal-900 mb-2">Email</h3>
                <p className="text-gray-600 font-light text-sm">
                  info@ambikajewellers.com
                </p>
              </div>
              
              <div className="bg-ivory p-6 rounded-sm">
                <Clock className="h-8 w-8 text-gold-500 mb-4" />
                <h3 className="font-serif text-xl text-charcoal-900 mb-2">Hours</h3>
                <p className="text-gray-600 font-light text-sm">
                  Mon - Sat: 11:00 AM - 9:00 PM<br />
                  Sunday: Closed
                </p>
              </div>
            </div>

            {/* Support Form */}
            <h3 className="font-serif text-2xl text-charcoal-900 mb-6">Send an Inquiry</h3>
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-charcoal-800 mb-2">First Name</label>
                  <input type="text" className="w-full border border-gray-300 rounded-sm px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-charcoal-800 mb-2">Last Name</label>
                  <input type="text" className="w-full border border-gray-300 rounded-sm px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-charcoal-800 mb-2">Email Address</label>
                <input type="email" className="w-full border border-gray-300 rounded-sm px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition" />
              </div>
              <div>
                <label className="block text-sm font-medium text-charcoal-800 mb-2">Message</label>
                <textarea rows={5} className="w-full border border-gray-300 rounded-sm px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition resize-none"></textarea>
              </div>
              <button type="submit" className="bg-charcoal-900 text-white hover:bg-gold-500 hover:text-charcoal-900 px-8 py-3 rounded-sm font-medium transition duration-300">
                Submit Inquiry
              </button>
            </form>
          </div>

          {/* Map Placeholder */}
          <div className="bg-gray-100 rounded-sm overflow-hidden h-[400px] lg:h-auto min-h-[500px] relative">
            {/* Embedded Google Map using a simple placeholder styling or an iframe */}
            <div className="absolute inset-0 w-full h-full">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d117763.55651584617!2d75.76015509999999!3d22.724128500000003!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3962fcad1b410ddb%3A0x96ec4da356240f4!2sIndore%2C%20Madhya%20Pradesh!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen={false} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Ambika Jewellers Location"
              ></iframe>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

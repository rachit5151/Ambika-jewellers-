import { Link } from 'react-router-dom';
import { ArrowLeft, Trash2, Heart } from 'lucide-react';
import { useWishlist } from '../context/WishlistContext';
import { flatProducts } from '../data/products';

export function Wishlist() {
  const { wishlist, toggleWishlist } = useWishlist();

  const savedProducts = flatProducts.filter(product => wishlist.includes(product.id));

  return (
    <div className="bg-ivory min-h-screen pt-12 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12">
          <Link to="/categories" className="inline-flex items-center text-gray-500 hover:text-gold-600 transition mb-6 font-light">
            <ArrowLeft className="w-4 h-4 mr-2" /> Continue Shopping
          </Link>
          <h1 className="font-serif text-3xl md:text-4xl text-charcoal-900 flex items-center">
            My Wishlist <Heart className="ml-3 h-8 w-8 text-gold-500 fill-current" />
          </h1>
          <div className="h-0.5 w-16 bg-gold-500 mt-4"></div>
        </div>

        {savedProducts.length === 0 ? (
          <div className="text-center py-24 bg-white rounded-sm shadow-sm border border-gray-100">
            <Heart className="mx-auto h-16 w-16 text-gray-300 mb-4" />
            <h2 className="font-serif text-2xl text-charcoal-900 mb-2">Your wishlist is empty</h2>
            <p className="text-gray-500 font-light mb-8">Save items you love to revisit them later.</p>
            <Link 
              to="/categories" 
              className="inline-block bg-charcoal-900 text-gold-500 hover:bg-gold-500 hover:text-charcoal-900 px-8 py-3 uppercase tracking-wider text-sm font-medium shadow-md transition duration-300"
            >
              Explore Collections
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {savedProducts.map((product) => (
              <div key={product.id} className="bg-white rounded-sm shadow-md overflow-hidden group relative">
                <div className="relative overflow-hidden aspect-[4/5]">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <button 
                    onClick={() => toggleWishlist(product.id)}
                    className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm p-2 rounded-full text-rose-500 hover:bg-rose-50 transition shadow-sm"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                  <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 font-medium text-charcoal-900 shadow-sm text-xs">
                    {product.price}
                  </div>
                </div>
                <div className="p-5 flex flex-col h-full">
                  <h3 className="font-serif text-lg text-charcoal-900 mb-2 line-clamp-1">{product.name}</h3>
                  <button className="w-full mt-4 border border-charcoal-900 text-charcoal-900 hover:bg-charcoal-900 hover:text-white transition py-2 font-medium tracking-wide text-xs">
                    View Details
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

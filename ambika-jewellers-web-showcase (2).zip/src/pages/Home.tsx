import { Link } from 'react-router-dom';
import { ShieldCheck, Gem, Sparkles, Star, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';

export function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center bg-charcoal-900">
        <div 
          className="absolute inset-0 z-0 opacity-40 bg-cover bg-center"
          style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1543294001-f7cd5d7fb516?auto=format&fit=crop&q=80&w=2000")' }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-900/60 to-charcoal-900/90"></div>
        </div>
        
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <h1 className="font-serif text-4xl md:text-6xl text-white mb-6 leading-tight">
            Elegance <span className="text-gold-500 italic">Within</span> Your Reach
          </h1>
          <p className="text-gray-300 text-lg md:text-xl font-light mb-10 max-w-2xl mx-auto">
            Premium Artificial Jewellery in Indore. Discover our royal collection of 1-gram gold and exquisite bridal pieces.
          </p>
          <Link 
            to="/categories" 
            className="inline-block bg-gold-500 text-charcoal-900 px-8 py-4 rounded-sm font-medium tracking-wide hover:bg-gold-400 transition duration-300 shadow-xl"
          >
            Explore Collections
          </Link>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-ivory">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-serif text-3xl md:text-4xl text-charcoal-900 mb-4">Why Choose Us</h2>
            <div className="h-0.5 w-16 bg-gold-500 mx-auto"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="flex flex-col items-center text-center p-6 bg-white rounded-sm shadow-sm border border-gray-100 transition hover:shadow-md">
              <div className="h-16 w-16 bg-gold-50 rounded-full flex items-center justify-center mb-6">
                <Gem className="h-8 w-8 text-gold-600" />
              </div>
              <h3 className="font-serif text-xl text-charcoal-900 mb-3">Premium Quality</h3>
              <p className="text-gray-600 font-light leading-relaxed">
                Meticulously crafted with high-grade materials, our 1-gram gold pieces offer the exact luster of real gold without the premium price tag.
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center p-6 bg-white rounded-sm shadow-sm border border-gray-100 transition hover:shadow-md">
              <div className="h-16 w-16 bg-gold-50 rounded-full flex items-center justify-center mb-6">
                <ShieldCheck className="h-8 w-8 text-gold-600" />
              </div>
              <h3 className="font-serif text-xl text-charcoal-900 mb-3">Affordable Luxury</h3>
              <p className="text-gray-600 font-light leading-relaxed">
                Experience royal elegance on any budget. We believe every occasion deserves grand aesthetics accessible to everyone.
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center p-6 bg-white rounded-sm shadow-sm border border-gray-100 transition hover:shadow-md">
              <div className="h-16 w-16 bg-gold-50 rounded-full flex items-center justify-center mb-6">
                <Sparkles className="h-8 w-8 text-gold-600" />
              </div>
              <h3 className="font-serif text-xl text-charcoal-900 mb-3">Latest Designs</h3>
              <p className="text-gray-600 font-light leading-relaxed">
                From traditional Polki to contemporary sleek styles, our collections are constantly updated to reflect current bridal and casual trends.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Section 1: Mangalsutra Types & Ratings */}
      <section className="py-24 bg-white border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-serif text-3xl md:text-4xl text-charcoal-900 mb-4">Sacred Bonds: Mangalsutra Collection</h2>
            <div className="h-0.5 w-16 bg-gold-500 mx-auto mb-6"></div>
            <p className="text-gray-500 font-light max-w-2xl mx-auto">
              Discover our top-rated mangalsutra designs tailored for every lifestyle and occasion.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Traditional */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="bg-ivory p-6 rounded-sm shadow-sm border border-gray-100 hover:border-gold-300 transition"
            >
              <h3 className="font-serif text-xl text-charcoal-900 mb-2">Traditional Maharashtrian Vati</h3>
              <div className="flex items-center text-gold-500 mb-4">
                <Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current" />
                <span className="ml-2 text-sm text-gray-600 font-medium">4.9/5</span>
              </div>
              <p className="text-gray-600 font-light text-sm leading-relaxed">
                Authentic twin-vati design honoring rich heritage. <br/>Perfect for traditional gatherings and pujas.
              </p>
            </motion.div>

            {/* Modern Minimalist */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-ivory p-6 rounded-sm shadow-sm border border-gray-100 hover:border-gold-300 transition"
            >
              <h3 className="font-serif text-xl text-charcoal-900 mb-2">Modern Minimalist</h3>
              <div className="flex items-center text-gold-500 mb-4">
                <Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current text-gold-300" />
                <span className="ml-2 text-sm text-gray-600 font-medium">4.8/5</span>
              </div>
              <p className="text-gray-600 font-light text-sm leading-relaxed">
                Sleek single-diamond or fine bead patterns. <br/>Designed exclusively for the modern working woman.
              </p>
            </motion.div>

            {/* Diamond-Studded */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-ivory p-6 rounded-sm shadow-sm border border-gray-100 hover:border-gold-300 transition"
            >
              <h3 className="font-serif text-xl text-charcoal-900 mb-2">Diamond-Studded Elegance</h3>
              <div className="flex items-center text-gold-500 mb-4">
                <Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current text-gold-300" />
                <span className="ml-2 text-sm text-gray-600 font-medium">4.7/5</span>
              </div>
              <p className="text-gray-600 font-light text-sm leading-relaxed">
                Luxurious American Diamond settings merged with black beads. <br/>A striking statement piece for evening events.
              </p>
            </motion.div>

            {/* 1-Gram Gold Daily Wear */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-ivory p-6 rounded-sm shadow-sm border border-gray-100 hover:border-gold-300 transition"
            >
              <h3 className="font-serif text-xl text-charcoal-900 mb-2">1-Gram Gold Daily Wear</h3>
              <div className="flex items-center text-gold-500 mb-4">
                <Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current" /><Star className="w-4 h-4 fill-current" />
                <span className="ml-2 text-sm text-gray-600 font-medium">4.9/5</span>
              </div>
              <p className="text-gray-600 font-light text-sm leading-relaxed">
                Durable micro-plated chains that withstand daily chores. <br/>Maintains its rich golden luster day after day.
              </p>
            </motion.div>
          </div>

          <div className="text-center mt-12">
            <Link 
              to="/categories/mangalsutra" 
              className="inline-block border border-charcoal-900 text-charcoal-900 px-8 py-3 uppercase tracking-wider text-sm font-medium hover:bg-charcoal-900 hover:text-gold-500 transition"
            >
              Explore All Mangalsutras
            </Link>
          </div>
        </div>
      </section>

      {/* Section 2: Bangles Collection Feature */}
      <section className="py-24 bg-charcoal-900 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-20 -mr-20 w-64 h-64 bg-gold-900/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-80 h-80 bg-gold-800/10 rounded-full blur-3xl"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center"
          >
            <div>
              <h2 className="font-serif text-3xl md:text-5xl text-gold-500 mb-6">Bangles & Kangan Collection</h2>
              <p className="text-gray-300 text-lg font-light leading-relaxed mb-6">
                Adorn your wrists with our masterfully crafted bangle collection. From heavy traditional wedding kangans that resonate with cultural grandeur, to sleek modern kadas offering subtle sophistication. 
              </p>
              <ul className="space-y-3 mb-10 text-gray-300 font-light">
                <li className="flex items-start">
                  <span className="text-gold-500 mr-3">✦</span>
                  <strong>Exquisite Craftsmanship:</strong> Detailed meenakari and stone settings.
                </li>
                <li className="flex items-start">
                  <span className="text-gold-500 mr-3">✦</span>
                  <strong>Skin-Friendly & Safe:</strong> Hypoallergenic materials for comfortable wear.
                </li>
                <li className="flex items-start">
                  <span className="text-gold-500 mr-3">✦</span>
                  <strong>Versatile Range:</strong> Perfect for daily-wear elegance or grand celebrations.
                </li>
              </ul>
              <Link 
                to="/categories/bangles" 
                className="inline-flex items-center border border-gold-500 text-gold-500 px-8 py-3 uppercase tracking-wider text-sm font-medium hover:bg-gold-500 hover:text-charcoal-900 transition"
              >
                Explore Bangles <ChevronRight className="ml-2 w-4 h-4" />
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <img src="https://images.unsplash.com/photo-1611591437281-460bfbe1220a?auto=format&fit=crop&q=80&w=600" alt="Gold Bangles" className="rounded-sm w-full h-64 object-cover mt-8 shadow-xl" />
              <img src="https://images.unsplash.com/photo-1599643477877-521ee2e27b6e?auto=format&fit=crop&q=80&w=600" alt="Traditional Kangan" className="rounded-sm w-full h-64 object-cover shadow-xl" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Section 3: What is Gold Polish Chain? */}
      <section className="py-24 bg-ivory">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-serif text-3xl md:text-4xl text-charcoal-900 mb-4">Understanding Our Gold Polish Chains</h2>
            <div className="h-0.5 w-16 bg-gold-500 mx-auto"></div>
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="bg-white p-8 md:p-12 rounded-sm shadow-lg border-t-4 border-gold-500"
          >
            <h3 className="font-serif text-2xl text-gold-600 mb-4">What is a Gold Polish Chain?</h3>
            <p className="text-gray-600 font-light leading-relaxed mb-8 text-lg">
              A high-quality Gold Polish (or 1-Gram Gold) Chain is crafted by applying a thick, real-gold layering over a strong, durable base metal (like copper or brass alloy). This specialized micro-plating technique ensures the piece looks and feels exactly like solid gold.
            </p>

            <h3 className="font-serif text-xl text-charcoal-900 mb-6">Why Choose Our Gold Polish Jewellery?</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="flex">
                <div className="h-10 w-10 bg-gold-50 flex items-center justify-center rounded-full mr-4 flex-shrink-0">
                  <span className="text-gold-600 font-bold">1</span>
                </div>
                <div>
                  <h4 className="font-medium text-charcoal-800 mb-2">Premium Identical Look</h4>
                  <p className="text-gray-600 text-sm font-light leading-relaxed">
                    Indistinguishable from solid 22k gold, allowing you to wear heavy, ornate designs with confidence.
                  </p>
                </div>
              </div>
              <div className="flex">
                <div className="h-10 w-10 bg-gold-50 flex items-center justify-center rounded-full mr-4 flex-shrink-0">
                  <span className="text-gold-600 font-bold">2</span>
                </div>
                <div>
                  <h4 className="font-medium text-charcoal-800 mb-2">Advanced Micro-Plating</h4>
                  <p className="text-gray-600 text-sm font-light leading-relaxed">
                    Our high-grade electroplating process ensures long-lasting shine that resists daily wear and tarnishing.
                  </p>
                </div>
              </div>
              <div className="flex">
                <div className="h-10 w-10 bg-gold-50 flex items-center justify-center rounded-full mr-4 flex-shrink-0">
                  <span className="text-gold-600 font-bold">3</span>
                </div>
                <div>
                  <h4 className="font-medium text-charcoal-800 mb-2">Allergy-Free Comfort</h4>
                  <p className="text-gray-600 text-sm font-light leading-relaxed">
                    Constructed with skin-friendly base alloys, making them safe and comfortable for extended daily use.
                  </p>
                </div>
              </div>
              <div className="flex">
                <div className="h-10 w-10 bg-gold-50 flex items-center justify-center rounded-full mr-4 flex-shrink-0">
                  <span className="text-gold-600 font-bold">4</span>
                </div>
                <div>
                  <h4 className="font-medium text-charcoal-800 mb-2">Affordable Daily Luxury</h4>
                  <p className="text-gray-600 text-sm font-light leading-relaxed">
                    Enjoy the premium aesthetic of gold chains for routine wear without securing expensive assets.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-12 pt-8 border-t border-gray-100 text-center">
              <Link 
                to="/categories/chains" 
                className="inline-block bg-gold-500 text-charcoal-900 px-8 py-3 uppercase tracking-wider text-sm font-medium hover:bg-gold-400 shadow-md transition"
              >
                Shop Gold Chains
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

    </div>
  );
}

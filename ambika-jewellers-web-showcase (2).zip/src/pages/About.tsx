import { Clock, MapPin, Send } from 'lucide-react';

export function About() {
  return (
    <div className="bg-ivory min-h-screen pt-12 pb-24">
      {/* Hero Header */}
      <div className="text-center mb-16 px-4">
        <h1 className="font-serif text-4xl md:text-5xl text-charcoal-900 mb-4">About Ambika Jewellers</h1>
        <div className="h-0.5 w-24 bg-gold-500 mx-auto"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-24">
          
          <div className="space-y-6">
            <h2 className="font-serif text-3xl text-charcoal-800">A Legacy of Elegance in Indore</h2>
            <p className="text-gray-600 font-light leading-relaxed text-lg">
              Located in the heart of Indore at Patel Colony, Ambika Jewellers is a premier destination for those who seek the aesthetic of real gold without the extravagant price. 
            </p>
            <p className="text-gray-600 font-light leading-relaxed text-lg">
              We specialize in high-quality <strong>1-Gram Gold jewellery</strong> and premium artificial styles suitable for both extravagant bridal wear and subtle casual styling. Our mission is to make every customer feel royal and radiant.
            </p>
            <p className="text-gray-600 font-light leading-relaxed text-lg">
              Each piece in our collection is carefully selected to ensure perfect finish, durability, and a genuine glow. We invite you to visit our store and experience the elegance firsthand.
            </p>
            <div className="pt-4">
               <img 
                src="https://images.unsplash.com/photo-1611085583191-a3b181a88401?auto=format&fit=crop&q=80&w=1000" 
                alt="Jewellery Details" 
                className="rounded-sm shadow-xl w-full h-[300px] object-cover"
              />
            </div>
          </div>

          <div className="space-y-12">
            {/* Store Timing Card */}
            <div className="bg-white p-8 rounded-sm shadow-lg border-t-4 border-gold-500">
              <h3 className="font-serif text-2xl text-charcoal-900 mb-6 flex items-center">
                <Clock className="mr-3 text-gold-500 h-6 w-6" /> 
                Store Timings & Location
              </h3>
              
              <div className="space-y-4 mb-8">
                <div className="flex justify-between border-b border-gray-100 pb-2">
                  <span className="text-gray-600">Monday - Saturday</span>
                  <span className="font-medium text-charcoal-800">11:00 AM - 9:00 PM</span>
                </div>
                <div className="flex justify-between border-b border-gray-100 pb-2">
                  <span className="text-gray-600">Sunday</span>
                  <span className="font-medium text-charcoal-800">Closed</span>
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-sm flex items-start">
                <MapPin className="text-gold-500 h-6 w-6 mr-3 mt-1 flex-shrink-0" />
                <p className="text-charcoal-800 font-medium">
                  Ambika Jewellers<br/>
                  <span className="text-gray-500 font-light text-sm mt-1 inline-block">
                    Shop No. 4, Main Market, Patel Colony,<br/>
                    Indore, Madhya Pradesh 452001
                  </span>
                </p>
              </div>
            </div>

            {/* Quick Contact Form Mock */}
            <div className="bg-charcoal-900 p-8 rounded-sm shadow-lg text-white">
              <h3 className="font-serif text-2xl text-gold-500 mb-6">Drop Us a Line</h3>
              <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                <div>
                  <input 
                    type="text" 
                    placeholder="Your Name" 
                    className="w-full bg-charcoal-800 border-charcoal-700 focus:border-gold-500 focus:ring-1 focus:ring-gold-500 border rounded-sm px-4 py-3 outline-none transition text-sm"
                  />
                </div>
                <div>
                  <input 
                    type="email" 
                    placeholder="Email Address" 
                    className="w-full bg-charcoal-800 border-charcoal-700 focus:border-gold-500 focus:ring-1 focus:ring-gold-500 border rounded-sm px-4 py-3 outline-none transition text-sm"
                  />
                </div>
                <div>
                  <textarea 
                    placeholder="Your Message..." 
                    rows={4}
                    className="w-full bg-charcoal-800 border-charcoal-700 focus:border-gold-500 focus:ring-1 focus:ring-gold-500 border rounded-sm px-4 py-3 outline-none transition text-sm resize-none"
                  ></textarea>
                </div>
                <button className="w-full bg-gold-500 hover:bg-gold-400 text-charcoal-900 font-medium py-3 rounded-sm transition flex items-center justify-center">
                  <Send className="w-4 h-4 mr-2" /> Send Message
                </button>
              </form>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}

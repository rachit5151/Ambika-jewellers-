import { useState, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, ArrowDownUp, Heart, X, Eye, ShoppingBag, Calendar, CheckCircle, XCircle } from 'lucide-react';
import { allProducts, categoryNames, Product } from '../data/products';
import { useWishlist } from '../context/WishlistContext';
import { useAuth } from '../context/AuthContext';

export function Products() {
  const { categoryId } = useParams<{ categoryId: string }>();
  const [sortBy, setSortBy] = useState('relevance');
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const { toggleWishlist, isInWishlist } = useWishlist();
  const { isAdmin } = useAuth();
  
  const products = categoryId ? allProducts[categoryId as keyof typeof allProducts] : [];
  const categoryName = categoryId ? categoryNames[categoryId] : 'Collection';

  const sortedProducts = useMemo(() => {
    if (!products) return [];
    
    const productsCopy = [...products];
    
    if (sortBy === 'price-asc') {
      productsCopy.sort((a, b) => {
        const priceA = parseInt(a.price.replace(/[^0-9]/g, ''), 10);
        const priceB = parseInt(b.price.replace(/[^0-9]/g, ''), 10);
        return priceA - priceB;
      });
    } else if (sortBy === 'price-desc') {
      productsCopy.sort((a, b) => {
        const priceA = parseInt(a.price.replace(/[^0-9]/g, ''), 10);
        const priceB = parseInt(b.price.replace(/[^0-9]/g, ''), 10);
        return priceB - priceA;
      });
    }
    
    return productsCopy;
  }, [products, sortBy]);

  if (!products) {
    return (
      <div className="min-h-[50vh] flex flex-col items-center justify-center bg-ivory">
        <h2 className="font-serif text-2xl text-charcoal-900 mb-4">Category Not Found</h2>
        <Link to="/categories" className="text-gold-600 hover:text-gold-700 flex items-center">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Collections
        </Link>
      </div>
    );
  }

  return (
    <div className="bg-ivory min-h-screen pt-12 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="mb-12 flex flex-col md:flex-row md:items-end md:justify-between">
          <div>
            <Link to="/categories" className="inline-flex items-center text-gray-500 hover:text-gold-600 transition mb-6 font-light">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Collections
            </Link>
            <h1 className="font-serif text-4xl text-charcoal-900">{categoryName}</h1>
            <div className="h-0.5 w-16 bg-gold-500 mt-4"></div>
          </div>
          
          <div className="mt-8 md:mt-0 flex items-center">
            <label htmlFor="sort" className="text-gray-500 text-sm font-light mr-3 whitespace-nowrap">Sort By:</label>
            <div className="relative">
              <select
                id="sort"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="appearance-none bg-white border border-gray-300 text-charcoal-800 text-sm rounded-sm pl-4 pr-10 py-2.5 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition cursor-pointer"
              >
                <option value="relevance">Relevance</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
              </select>
              <ArrowDownUp className="absolute right-3 top-3 h-4 w-4 text-gray-400 pointer-events-none" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
          {sortedProducts.map((product) => (
            <div key={product.id} className="bg-white rounded-sm shadow-md overflow-hidden group">
              <div className="relative overflow-hidden aspect-[4/5]">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                
                {/* Quick View Overlay Button */}
                <div className="absolute inset-0 bg-charcoal-900/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center z-10 pointer-events-none group-hover:pointer-events-auto">
                  <button 
                    onClick={() => setQuickViewProduct({...product, category: categoryId as string})}
                    className="bg-white text-charcoal-900 px-6 py-2.5 rounded-sm font-medium text-sm flex items-center transform translate-y-4 group-hover:translate-y-0 transition-all duration-300 shadow-lg hover:bg-charcoal-900 hover:text-gold-500"
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Quick View
                  </button>
                </div>

                <button 
                  onClick={() => toggleWishlist(product.id)}
                  className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm p-2 rounded-full hover:bg-gold-50 transition shadow-sm z-20"
                >
                  <Heart className={`h-4 w-4 ${isInWishlist(product.id) ? 'fill-gold-500 text-gold-500' : 'text-gray-400 hover:text-gold-500'}`} />
                </button>
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 font-medium text-charcoal-900 shadow-sm text-sm z-20">
                  {product.price}
                </div>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-serif text-xl text-charcoal-900">{product.name}</h3>
                </div>
                <p className="text-gray-500 text-sm font-light mb-6 line-clamp-2">
                  {product.description}
                </p>
                <div className="flex gap-2">
                  {product.inStock !== false ? (
                    <>
                      <div className="flex-1 border border-gray-200 bg-green-50 flex items-center justify-center py-2.5 text-xs font-medium text-green-600 tracking-wide">
                        <CheckCircle className="w-3.5 h-3.5 mr-1.5" />
                        Available
                      </div>
                      <button className="flex-1 border border-charcoal-900 bg-charcoal-900 text-white hover:bg-gold-500 hover:border-gold-500 hover:text-charcoal-900 transition py-2.5 font-medium tracking-wide text-sm">
                        Book Now
                      </button>
                    </>
                  ) : (
                    <>
                      <div className="flex-1 border border-gray-200 bg-red-50 flex items-center justify-center py-2.5 text-xs font-medium text-red-600 tracking-wide">
                        <XCircle className="w-3.5 h-3.5 mr-1.5" />
                        Out of Stock
                      </div>
                      <button disabled className="flex-1 border border-gray-300 bg-gray-100 text-gray-400 cursor-not-allowed transition py-2.5 font-medium tracking-wide text-sm">
                        Unavailable
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {products.length === 0 && (
          <div className="text-center py-24 text-gray-500">
            No products found in this category.
          </div>
        )}

        {/* Quick View Modal */}
        {quickViewProduct && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div 
              className="absolute inset-0 bg-charcoal-900/60 backdrop-blur-sm"
              onClick={() => setQuickViewProduct(null)}
            ></div>
            
            <div className="bg-ivory max-w-4xl w-full rounded-sm shadow-2xl relative z-10 flex flex-col md:flex-row overflow-hidden max-h-[90vh]">
              <button 
                onClick={() => setQuickViewProduct(null)}
                className="absolute top-4 right-4 bg-white/50 backdrop-blur-sm hover:bg-white p-2 text-charcoal-900 transition z-10 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
              
              <div className="w-full md:w-1/2 aspect-square md:aspect-auto h-64 md:h-auto bg-gray-50">
                <img 
                  src={quickViewProduct.image} 
                  alt={quickViewProduct.name} 
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="w-full md:w-1/2 p-8 md:p-12 overflow-y-auto bg-white flex flex-col justify-center">
                <div className="uppercase tracking-widest text-gold-600 text-xs font-bold mb-2">
                  {categoryNames[quickViewProduct.category] || 'Collection'}
                </div>
                <h2 className="font-serif text-3xl text-charcoal-900 mb-4">{quickViewProduct.name}</h2>
                <div className="text-2xl text-charcoal-800 font-medium mb-6">{quickViewProduct.price}</div>
                
                <div className="h-px bg-gray-100 mb-6"></div>
                
                {quickViewProduct.inStock !== false ? (
                  <div className="flex items-center mb-6 pl-3 py-2.5 bg-green-50/50 border border-green-100 rounded-sm">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm font-medium text-green-700 tracking-wide">Status: Available for Booking</span>
                  </div>
                ) : (
                  <div className="flex items-center mb-6 pl-3 py-2.5 bg-red-50/50 border border-red-100 rounded-sm">
                    <XCircle className="w-5 h-5 text-red-500 mr-3" />
                    <span className="text-sm font-medium text-red-700 tracking-wide">Status: Out of Stock</span>
                  </div>
                )}
                
                <p className="text-gray-600 leading-relaxed font-light mb-8">
                  {quickViewProduct.description}
                </p>
                
                <div className="space-y-4">
                  <button 
                    disabled={quickViewProduct.inStock === false}
                    className={`w-full transition py-3.5 font-medium tracking-wide flex items-center justify-center shadow-lg ${
                      quickViewProduct.inStock !== false
                        ? 'bg-charcoal-900 text-gold-500 hover:bg-gold-500 hover:text-charcoal-900'
                        : 'bg-gray-200 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    <Calendar className="w-5 h-5 mr-3" />
                    {quickViewProduct.inStock !== false ? 'Book Appointment' : 'Out of Stock'}
                  </button>
                  <button 
                    onClick={() => toggleWishlist(quickViewProduct.id)}
                    className={`w-full border py-3.5 font-medium tracking-wide flex items-center justify-center transition-colors ${
                      isInWishlist(quickViewProduct.id) 
                        ? 'border-gold-500 text-gold-600 bg-gold-50' 
                        : 'border-gray-200 text-charcoal-900 hover:border-gold-500 hover:text-gold-600'
                    }`}
                  >
                    <Heart className={`w-5 h-5 mr-3 ${isInWishlist(quickViewProduct.id) ? 'fill-gold-500' : ''}`} />
                    {isInWishlist(quickViewProduct.id) ? 'Saved to Wishlist' : 'Add to Wishlist'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
